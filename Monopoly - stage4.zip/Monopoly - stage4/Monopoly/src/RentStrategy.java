public interface RentStrategy {

    int calculateRent(int baseRent);
}