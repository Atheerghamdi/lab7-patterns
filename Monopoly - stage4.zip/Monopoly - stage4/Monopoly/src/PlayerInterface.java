public interface PlayerInterface {

    public void nextTurn();
    public int tossDie(Die die);
}